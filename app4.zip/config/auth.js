module.exports = {
	'facebookAuth' : {
		'clientID': '480643022396586',
		'clientSecret': '34295cadcbb3b42ef0db8ff0fa7b8ae6',
		'callbackURL': 'http://whiterosetaxi-env-1.43ae4w924i.us-east-2.elasticbeanstalk.com/user'
	},

	'googleAuth' : {
		'clientID': 'enter client id here',
		'clientSecret': 'enter client secret here',
		'callbackURL': 'enter callback here'
	}
}